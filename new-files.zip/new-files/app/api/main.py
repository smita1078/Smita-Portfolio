"""
FastAPI app. Run with:  uvicorn app.api.main:app --reload
Then open http://localhost:8000 in a browser.

Serves both the JSON API (under /api/...) and the static dashboard frontend
(everything else) from one process - no separate frontend server/build step
needed, which matters for running this on a locked-down company machine.
"""
from pathlib import Path
from fastapi import FastAPI, Depends, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session

from app.database import get_db, engine, Base
from app.services import analysis

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Cyber Hygiene Vulnerability Dashboard API")

# CORS left open for local dev convenience; tighten if this ever runs
# somewhere reachable beyond your own machine.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/sources")
def get_sources():
    return [
        {"id": "cm", "label": "CM-Radar"},
        {"id": "prisma", "label": "Prisma-GCP"},
        {"id": "oss", "label": "Composite Viewer"},
    ]


@app.get("/api/weeks")
def get_weeks(source: str, db: Session = Depends(get_db)):
    if source not in ("cm", "prisma", "oss"):
        raise HTTPException(400, "source must be one of: cm, prisma, oss")
    return analysis.list_available_weeks(db, source)


@app.get("/api/pivot")
def get_pivot(source: str, report_date: str, db: Session = Depends(get_db)):
    if source == "cm":
        return analysis.cm_severity_pivot(db, report_date)
    elif source == "prisma":
        return analysis.prisma_severity_owner_pivot(db, report_date)
    elif source == "oss":
        return analysis.oss_severity_owner_pivot(db, report_date)
    raise HTTPException(400, "source must be one of: cm, prisma, oss")


@app.get("/api/compare")
def get_compare(source: str, current_week: str, prior_week: str, db: Session = Depends(get_db)):
    if source not in ("cm", "prisma", "oss"):
        raise HTTPException(400, "source must be one of: cm, prisma, oss")
    return analysis.compare_weeks(db, source, current_week, prior_week)


@app.get("/api/trend")
def get_trend(source: str, db: Session = Depends(get_db)):
    if source not in ("cm", "prisma", "oss"):
        raise HTTPException(400, "source must be one of: cm, prisma, oss")
    return analysis.all_weeks_severity_trend(db, source)


# Serve the frontend (static HTML/JS/CSS) at the root path.
# Placed last so it doesn't shadow the /api/* routes above.
frontend_dir = Path(__file__).resolve().parent.parent.parent / "frontend"
if frontend_dir.exists():
    app.mount("/", StaticFiles(directory=str(frontend_dir), html=True), name="frontend")
