"""
Computes the pivot/summary views the dashboard needs, directly from the raw
finding tables. At thousands-of-rows-per-week scale this is fast enough to
compute on read rather than needing a separate precomputed snapshot table -
simpler to keep correct while the schema is still settling. (If volume grows
much later, this is the natural place to add caching or move to the
weekly_snapshot/delta tables already in the schema.)
"""
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.models.cm_finding import CMFinding
from app.models.prisma_finding import PrismaFinding
from app.models.oss_snapshot import OSSComponentSnapshot
from app.models.scan_batch import ScanBatch

SEVERITY_ORDER = ["Critical", "High", "Medium", "Low", "Unknown"]


def list_available_weeks(db: Session, source: str) -> list[str]:
    dates = (
        db.query(ScanBatch.report_date)
        .filter(ScanBatch.source == source, ScanBatch.status == "completed")
        .distinct()
        .order_by(ScanBatch.report_date.desc())
        .all()
    )
    return [d[0].isoformat() for d in dates]


def _batch_ids_for(db: Session, source: str, report_date: str) -> list[int]:
    rows = (
        db.query(ScanBatch.id)
        .filter(ScanBatch.source == source, ScanBatch.report_date == report_date)
        .all()
    )
    return [r[0] for r in rows]


def cm_severity_pivot(db: Session, report_date: str) -> dict:
    """CM: severity counts only, no owner dimension - per team's confirmation."""
    batch_ids = _batch_ids_for(db, "cm", report_date)
    if not batch_ids:
        return {"report_date": report_date, "rows": [], "total": 0}

    counts = (
        db.query(CMFinding.severity_normalized, func.count(CMFinding.id))
        .filter(CMFinding.scan_batch_id.in_(batch_ids))
        .group_by(CMFinding.severity_normalized)
        .all()
    )
    count_map = {sev: cnt for sev, cnt in counts}
    rows = [{"severity": sev, "count": count_map.get(sev, 0)} for sev in SEVERITY_ORDER if count_map.get(sev)]
    return {"report_date": report_date, "rows": rows, "total": sum(count_map.values())}


def prisma_severity_owner_pivot(db: Session, report_date: str) -> dict:
    """Prisma: severity x owner grid (final_owner - after all override rules applied)."""
    batch_ids = _batch_ids_for(db, "prisma", report_date)
    if not batch_ids:
        return {"report_date": report_date, "owners": [], "rows": [], "totals_by_owner": {}, "total": 0}

    counts = (
        db.query(PrismaFinding.severity_normalized, PrismaFinding.final_owner, func.count(PrismaFinding.id))
        .filter(PrismaFinding.scan_batch_id.in_(batch_ids))
        .group_by(PrismaFinding.severity_normalized, PrismaFinding.final_owner)
        .all()
    )
    return _build_severity_owner_grid(counts, report_date)


def oss_severity_owner_pivot(db: Session, report_date: str) -> dict:
    """
    OSS: severity x owner grid, but summed from the pre-aggregated count
    columns (critical_count/high_count/etc.) rather than COUNT(*), since this
    source reports counts per component, not one row per vulnerability.
    """
    batch_ids = _batch_ids_for(db, "oss", report_date)
    if not batch_ids:
        return {"report_date": report_date, "owners": [], "rows": [], "totals_by_owner": {}, "total": 0}

    rows = (
        db.query(
            OSSComponentSnapshot.owner,
            func.sum(OSSComponentSnapshot.critical_count),
            func.sum(OSSComponentSnapshot.high_count),
            func.sum(OSSComponentSnapshot.medium_count),
            func.sum(OSSComponentSnapshot.low_count),
        )
        .filter(OSSComponentSnapshot.scan_batch_id.in_(batch_ids))
        .group_by(OSSComponentSnapshot.owner)
        .all()
    )

    counts = []
    for owner, crit, high, med, low in rows:
        for sev, cnt in [("Critical", crit), ("High", high), ("Medium", med), ("Low", low)]:
            if cnt:
                counts.append((sev, owner or "Unassigned", cnt))

    return _build_severity_owner_grid(counts, report_date)


def _build_severity_owner_grid(counts: list[tuple], report_date: str) -> dict:
    owners = sorted({owner or "Unassigned" for _, owner, _ in counts})
    grid = {sev: {o: 0 for o in owners} for sev in SEVERITY_ORDER}
    totals_by_owner = {o: 0 for o in owners}
    total = 0

    for sev, owner, cnt in counts:
        owner = owner or "Unassigned"
        if sev not in grid:
            grid[sev] = {o: 0 for o in owners}
        grid[sev][owner] = grid[sev].get(owner, 0) + cnt
        totals_by_owner[owner] = totals_by_owner.get(owner, 0) + cnt
        total += cnt

    rows = [
        {"severity": sev, **grid[sev], "total": sum(grid[sev].values())}
        for sev in SEVERITY_ORDER
        if sum(grid[sev].values()) > 0
    ]

    return {"report_date": report_date, "owners": owners, "rows": rows, "totals_by_owner": totals_by_owner, "total": total}


def all_weeks_severity_trend(db: Session, source: str) -> dict:
    """
    Severity totals across every ingested week for this source, oldest first -
    what a trend line chart needs (vs. the two-week-only compare_weeks above).
    """
    weeks = list_available_weeks(db, source)
    weeks_sorted = sorted(weeks)  # oldest first for a left-to-right trend line

    if source == "cm":
        pivot_fn = cm_severity_pivot
        get_map = lambda p: {r["severity"]: r["count"] for r in p["rows"]}
    else:
        pivot_fn = prisma_severity_owner_pivot if source == "prisma" else oss_severity_owner_pivot
        get_map = lambda p: {r["severity"]: r["total"] for r in p["rows"]}

    series_by_severity = {sev: [] for sev in SEVERITY_ORDER}
    for week in weeks_sorted:
        week_map = get_map(pivot_fn(db, week))
        for sev in SEVERITY_ORDER:
            series_by_severity[sev].append(week_map.get(sev, 0))

    # drop severities that are all-zero across every week (nothing to plot)
    series_by_severity = {sev: vals for sev, vals in series_by_severity.items() if any(vals)}

    return {"source": source, "weeks": weeks_sorted, "series": series_by_severity}
    """
    Week-over-week comparison, mirroring the original Summary sheet's
    "Vulnerabilities Count" + "Overall Progress" layout. Works per-source,
    since sources are analyzed independently (no cross-source join).
    """
    if source == "cm":
        current = cm_severity_pivot(db, current_week)
        prior = cm_severity_pivot(db, prior_week)
        current_map = {r["severity"]: r["count"] for r in current["rows"]}
        prior_map = {r["severity"]: r["count"] for r in prior["rows"]}
    else:
        pivot_fn = prisma_severity_owner_pivot if source == "prisma" else oss_severity_owner_pivot
        current = pivot_fn(db, current_week)
        prior = pivot_fn(db, prior_week)
        current_map = {r["severity"]: r["total"] for r in current["rows"]}
        prior_map = {r["severity"]: r["total"] for r in prior["rows"]}

    all_severities = sorted(set(current_map) | set(prior_map), key=lambda s: SEVERITY_ORDER.index(s) if s in SEVERITY_ORDER else 99)

    comparison_rows = []
    for sev in all_severities:
        cur_count = current_map.get(sev, 0)
        prior_count = prior_map.get(sev, 0)
        net_change = cur_count - prior_count
        pct = round((net_change / prior_count * 100), 1) if prior_count else None
        comparison_rows.append({
            "severity": sev,
            "current_count": cur_count,
            "prior_count": prior_count,
            "net_change": net_change,
            "pct_improvement": pct,
        })

    return {
        "source": source,
        "current_week": current_week,
        "prior_week": prior_week,
        "rows": comparison_rows,
        "current_total": sum(current_map.values()),
        "prior_total": sum(prior_map.values()),
    }
