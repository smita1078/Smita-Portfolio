const API = "/api";

const SOURCES = [
  { id: "cm", label: "CM-Radar" },
  { id: "prisma", label: "Prisma-GCP" },
  { id: "oss", label: "Composite Viewer" },
];

let state = {
  source: "cm",
  week: null,
  priorWeek: null,
  compareMode: false,
};

async function fetchJSON(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Request failed: ${url}`);
  return res.json();
}

const SEVERITY_COLORS = {
  Critical: "#b91c1c",
  High: "#c2410c",
  Medium: "#a16207",
  Low: "#15803d",
  Unknown: "#6b6b64",
};

let severityChart = null;
let trendChart = null;

function renderSeverityChart(pivot) {
  const ctx = document.getElementById("severity-chart");
  const rows = pivot.rows || [];
  const labels = rows.map((r) => r.severity);
  const values = rows.map((r) => (r.total !== undefined ? r.total : r.count));
  const colors = labels.map((s) => SEVERITY_COLORS[s] || "#999");

  if (severityChart) severityChart.destroy();
  if (labels.length === 0) return;

  severityChart = new Chart(ctx, {
    type: "bar",
    data: {
      labels,
      datasets: [{ label: "Open findings", data: values, backgroundColor: colors, borderRadius: 4 }],
    },
    options: {
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true, ticks: { precision: 0 } } },
    },
  });
}

async function renderTrendChart() {
  const ctx = document.getElementById("trend-chart");
  const trend = await fetchJSON(`${API}/trend?source=${state.source}`);

  if (trendChart) trendChart.destroy();
  if (trend.weeks.length === 0 || Object.keys(trend.series).length === 0) return;

  const datasets = Object.entries(trend.series).map(([severity, values]) => ({
    label: severity,
    data: values,
    borderColor: SEVERITY_COLORS[severity] || "#999",
    backgroundColor: SEVERITY_COLORS[severity] || "#999",
    tension: 0.25,
    pointRadius: 3,
  }));

  trendChart = new Chart(ctx, {
    type: "line",
    data: { labels: trend.weeks, datasets },
    options: {
      plugins: { legend: { position: "bottom" } },
      scales: { y: { beginAtZero: true, ticks: { precision: 0 } } },
    },
  });
}

function renderTabs() {
  const nav = document.getElementById("source-tabs");
  nav.innerHTML = "";
  SOURCES.forEach((s) => {
    const btn = document.createElement("button");
    btn.className = "tab-btn" + (s.id === state.source ? " active" : "");
    btn.textContent = s.label;
    btn.onclick = () => {
      state.source = s.id;
      state.week = null;
      state.priorWeek = null;
      init();
    };
    nav.appendChild(btn);
  });
}

async function loadWeeks() {
  const weeks = await fetchJSON(`${API}/weeks?source=${state.source}`);
  const weekSelect = document.getElementById("week-select");
  const priorSelect = document.getElementById("prior-week-select");
  weekSelect.innerHTML = "";
  priorSelect.innerHTML = "";

  if (weeks.length === 0) {
    weekSelect.innerHTML = `<option value="">No data ingested yet</option>`;
    return weeks;
  }

  weeks.forEach((w) => {
    weekSelect.innerHTML += `<option value="${w}">${w}</option>`;
    priorSelect.innerHTML += `<option value="${w}">${w}</option>`;
  });

  state.week = weeks[0];
  state.priorWeek = weeks.length > 1 ? weeks[1] : weeks[0];
  weekSelect.value = state.week;
  priorSelect.value = state.priorWeek;
  return weeks;
}

function severityRowClass(sev) {
  return `sev-${sev}`;
}

function renderCMPivot(pivot) {
  if (pivot.rows.length === 0) return `<div class="empty-state">No findings for this week.</div>`;
  const rows = pivot.rows
    .map(
      (r) => `<tr class="${severityRowClass(r.severity)}">
        <td><span class="sev-badge"></span>${r.severity}</td>
        <td>${r.count}</td>
      </tr>`
    )
    .join("");
  return `
    <table>
      <thead><tr><th>Severity</th><th>Open Count</th></tr></thead>
      <tbody>${rows}</tbody>
      <tfoot><tr><td>Total</td><td>${pivot.total}</td></tr></tfoot>
    </table>`;
}

function renderOwnerPivot(pivot) {
  if (pivot.rows.length === 0) return `<div class="empty-state">No findings for this week.</div>`;
  const ownerHeaders = pivot.owners.map((o) => `<th>${o}</th>`).join("");
  const rows = pivot.rows
    .map((r) => {
      const cells = pivot.owners.map((o) => `<td>${r[o] || 0}</td>`).join("");
      return `<tr class="${severityRowClass(r.severity)}">
        <td><span class="sev-badge"></span>${r.severity}</td>
        ${cells}
        <td>${r.total}</td>
      </tr>`;
    })
    .join("");
  const totalCells = pivot.owners.map((o) => `<td>${pivot.totals_by_owner[o] || 0}</td>`).join("");
  return `
    <table>
      <thead><tr><th>Severity</th>${ownerHeaders}<th>Total</th></tr></thead>
      <tbody>${rows}</tbody>
      <tfoot><tr><td>Total</td>${totalCells}<td>${pivot.total}</td></tr></tfoot>
    </table>`;
}

function renderCompare(compare) {
  if (compare.rows.length === 0) return `<div class="empty-state">No comparable data for these weeks.</div>`;
  const rows = compare.rows
    .map((r) => {
      const pctClass = r.pct_improvement == null ? "neutral" : r.pct_improvement < 0 ? "positive" : r.pct_improvement > 0 ? "negative" : "neutral";
      const pctLabel = r.pct_improvement == null ? "—" : `${r.pct_improvement > 0 ? "+" : ""}${r.pct_improvement}%`;
      return `<tr class="${severityRowClass(r.severity)}">
        <td><span class="sev-badge"></span>${r.severity}</td>
        <td>${r.current_count}</td>
        <td>${r.prior_count}</td>
        <td class="${r.net_change < 0 ? "positive" : r.net_change > 0 ? "negative" : "neutral"}">${r.net_change > 0 ? "+" : ""}${r.net_change}</td>
        <td class="${pctClass}">${pctLabel}</td>
      </tr>`;
    })
    .join("");
  return `
    <div class="section-title">Week-over-Week Comparison — ${compare.current_week} vs ${compare.prior_week}</div>
    <table>
      <thead>
        <tr>
          <th>Severity</th>
          <th>${compare.current_week}</th>
          <th>${compare.prior_week}</th>
          <th>Net Change</th>
          <th>% Improvement</th>
        </tr>
      </thead>
      <tbody>${rows}</tbody>
      <tfoot>
        <tr>
          <td>Total</td>
          <td>${compare.current_total}</td>
          <td>${compare.prior_total}</td>
          <td>${compare.current_total - compare.prior_total >= 0 ? "+" : ""}${compare.current_total - compare.prior_total}</td>
          <td>—</td>
        </tr>
      </tfoot>
    </table>`;
}

async function renderPivotView() {
  const container = document.getElementById("pivot-view");
  if (!state.week) {
    container.innerHTML = "";
    return;
  }
  const pivot = await fetchJSON(`${API}/pivot?source=${state.source}&report_date=${state.week}`);
  renderSeverityChart(pivot);
  container.innerHTML =
    `<div class="section-title">${state.week}</div>` +
    (state.source === "cm" ? renderCMPivot(pivot) : renderOwnerPivot(pivot));
}

async function renderCompareView() {
  const container = document.getElementById("compare-view");
  if (!state.compareMode || !state.week || !state.priorWeek) {
    container.style.display = "none";
    container.innerHTML = "";
    return;
  }
  container.style.display = "block";
  const compare = await fetchJSON(
    `${API}/compare?source=${state.source}&current_week=${state.week}&prior_week=${state.priorWeek}`
  );
  container.innerHTML = renderCompare(compare);
}

function showStatus(message) {
  const banner = document.getElementById("status-banner");
  if (!message) {
    banner.style.display = "none";
    return;
  }
  banner.style.display = "block";
  banner.textContent = message;
}

async function init() {
  renderTabs();
  showStatus("Loading…");
  try {
    const weeks = await loadWeeks();
    if (weeks.length === 0) {
      showStatus(
        `No data ingested yet for this source. Run: python -m app.ingest --source ${state.source} --file <your file> --date YYYY-MM-DD`
      );
      document.getElementById("pivot-view").innerHTML = "";
      document.getElementById("compare-view").innerHTML = "";
      return;
    }
    showStatus(null);
    await renderPivotView();
    await renderTrendChart();
    await renderCompareView();
  } catch (e) {
    showStatus(`Error loading data: ${e.message}`);
  }
}

document.getElementById("week-select").addEventListener("change", async (e) => {
  state.week = e.target.value;
  await renderPivotView();
  await renderCompareView();
});

document.getElementById("prior-week-select").addEventListener("change", async (e) => {
  state.priorWeek = e.target.value;
  await renderCompareView();
});

document.getElementById("compare-toggle").addEventListener("change", async (e) => {
  state.compareMode = e.target.checked;
  document.getElementById("prior-week-group").style.display = state.compareMode ? "flex" : "none";
  await renderCompareView();
});

init();
